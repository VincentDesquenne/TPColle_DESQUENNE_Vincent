<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    {!! Html::style('lib/bootstrap/bootstrap.css') !!}

    <title>@yield('titrePage')</title>
</head>
<body class = "bg-secondary text-black">

<header>
    <ul class="nav justify-content-center">
        <li class="nav-item">
            <a class="nav-link text-dark font-weight-bold h2" href="#">Filmothèque</a>
        </li>
    </ul>
    <h1>@yield('titreItem')</h1>
</header>
@yield('contenu')

<footer class="footer text-center">
    <p>Filmothèque - DESQUENNE Vincent</p>
</footer>
{!! Html::script('lib/jquery/jquery-3.5.1.js') !!}
{!! Html::script('lib/js/bootstrap.bundle.js') !!}
{!! Html::script('lib/js/bootstrap.js/bootstrap.js') !!}
</body>
</html>
