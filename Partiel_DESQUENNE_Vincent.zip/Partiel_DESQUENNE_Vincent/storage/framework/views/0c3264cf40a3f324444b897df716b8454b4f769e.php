<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <?php echo Html::style('lib/bootstrap/bootstrap.css'); ?>


    <title><?php echo $__env->yieldContent('titrePage'); ?></title>
</head>
<body class = "bg-secondary text-black">

<header>
    <ul class="nav justify-content-center">
        <li class="nav-item">
            <a class="nav-link text-dark font-weight-bold h2" href="#">Filmothèque</a>
        </li>
    </ul>
    <h1><?php echo $__env->yieldContent('titreItem'); ?></h1>
</header>
<?php echo $__env->yieldContent('contenu'); ?>

<footer class="footer text-center">
    <p>Filmothèque - DESQUENNE Vincent</p>
</footer>
<?php echo Html::script('lib/jquery/jquery-3.5.1.js'); ?>

<?php echo Html::script('lib/js/bootstrap.bundle.js'); ?>

<?php echo Html::script('lib/js/bootstrap.js/bootstrap.js'); ?>

</body>
</html>
<?php /**PATH C:\xampp2\htdocs\Laravel\Partiel\resources\views/template.blade.php ENDPATH**/ ?>